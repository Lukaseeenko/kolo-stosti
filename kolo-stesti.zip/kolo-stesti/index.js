const { Client, GatewayIntentBits, MessageAttachment, MessageEmbed } = require('discord.js');
const { createCanvas } = require('canvas'); // Importujeme canvas
const token = process.env.TOKEN; // Načítáme token bota

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
  ]
});

// Seznam cen
const prizes = [
  "AK-47 | Redline",
  "M4A4 | Howl",
  "AWP | Dragon Lore",
  "Glock-18 | Fade",
  "Butterfly Knife | Case Hardened",
  "StatTrak™ AK-47 | Fire Serpent",
  "MP7 | Akimbo"
];

// Funkce pro vytvoření obrázku kola štěstí
async function createWheelImage(prizes) {
  const canvas = createCanvas(500, 500); // Vytvoříme plátno pro kolo
  const ctx = canvas.getContext('2d');
  const wheelRadius = 200; // Poloměr kola
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;

  console.log("Generování obrázku kola štěstí...");

  // Nastavení pozadí kola (bílý kruh)
  ctx.fillStyle = '#ffffff';
  ctx.arc(centerX, centerY, wheelRadius, 0, Math.PI * 2);
  ctx.fill();

  // Počítáme počet segmentů na kole
  const segmentAngle = Math.PI * 2 / prizes.length;

  // Vykreslení segmentů
  prizes.forEach((prize, index) => {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, wheelRadius, segmentAngle * index, segmentAngle * (index + 1));
    ctx.fillStyle = `hsl(${(index * 360) / prizes.length}, 100%, 60%)`;
    ctx.fill();
    ctx.restore();

    // Text na každém segmentu
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(segmentAngle * index + segmentAngle / 2);
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 18px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(prize, wheelRadius - 40, 0);
    ctx.restore();
  });

  // Kontrola generování obrázku
  console.log("Obrázek kola byl úspěšně vytvořen.");

  return canvas.toBuffer();
}

// Po připojení bota do Discordu
client.once('ready', () => {
  console.log('Bot je připojený a připravený!');
});

// Při přijetí zprávy od uživatele
client.on('messageCreate', async (message) => {
  if (message.content === '!kolo') {
    const voiceChannel = message.member.voice.channel;

    if (!voiceChannel) {
      return message.reply('Musíš být připojený do voice kanálu, aby ses mohl zúčastnit!');
    }

    // Získání účastníků ve voice kanálu
    const members = voiceChannel.members.filter(member => !member.user.bot).map(member => member.user.username);

    if (members.length === 0) {
      return message.reply('V místnosti není žádný účastník.');
    }

    // Vytvoření obrázku kola
    try {
      const wheelImage = await createWheelImage(prizes); // Tvoříme obrázek kola
      console.log('Obrázek kola byl úspěšně vytvořen.');

      // Vytvoření embed zprávy
      const embed = new MessageEmbed()
        .setTitle('🎡 Kolo štěstí se točí...')
        .setDescription('Klikněte na tlačítko níže pro zjištění, co jste vyhráli!')
        .setColor('#00FF00')
        .setImage('attachment://wheel.png'); // Obrázek z přílohy

      // Odeslání obrázku na Discord pomocí embed zprávy
      const attachment = new MessageAttachment(wheelImage, 'wheel.png');
      await message.channel.send({
        embeds: [embed],
        files: [attachment]
      });

      // Náhodný výběr vítěze
      setTimeout(() => {
        const winner = members[Math.floor(Math.random() * members.length)];
        const prize = prizes[Math.floor(Math.random() * prizes.length)];
        message.channel.send(`${winner} vyhrál cenu: **${prize}**! 🎉`);
      }, 3000); // Po 3 sekundách vybere vítěze
    } catch (error) {
      console.error('Chyba při generování obrázku kola:', error);
      message.channel.send('Došlo k chybě při vytváření obrázku kola štěstí.');
    }
  }
});

// Připojení bota na Discord server
client.login(token);
